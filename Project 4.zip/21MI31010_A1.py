import numpy as np
import pandas as pd
#Loading data file
BC = pd.read_csv(r'D:\College\Semester 5\Breadth - application of Machine learning in biological systems\Assignments\Post mid-sem\Project 1\breast cancer.csv')


#dropping the extra column 'unnamed'
BC = BC.loc[:, ~BC.columns.str.contains('^Unnamed')]
#dropping "id" column
BC = BC.drop(["id"],axis=1)


from sklearn.preprocessing import LabelEncoder

# Creating a instance of label Encoder.
le = LabelEncoder()

# Using .fit_transform function to fit label
# encoder and return encoded label
diag = pd.DataFrame(le.fit_transform(BC['diagnosis']))


# removing the column 'diagnosis' from BC
BC.drop(["diagnosis"], axis=1, inplace=True)


#Scaling the dataset
from sklearn.preprocessing import StandardScaler
scale = StandardScaler()

bc = pd.DataFrame(scale.fit_transform(BC),columns = BC.columns)

# Appending the labelled diagnosis to our dataFrame 
# with column name 'Diagnosis'
bc["diagnosis"] = diag

x = bc.drop(["diagnosis"],axis=1) # Features
y = bc["diagnosis"] # Target


# split the dataset into train and test
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(
    x, y, test_size=0.1, random_state=10)


#accuracy measure
def compute_accuracy(Y_true, Y_pred):  
    correctly_predicted = 0  
    # iterating over every label and checking it with the true sample  
    for true_label, predicted in zip(Y_true, Y_pred):  
        if true_label == predicted:  
            correctly_predicted += 1  
    # computing the accuracy score  
    accuracy = correctly_predicted / len(Y_true)*100
    return accuracy

#logistic regression model
class LR():
    def __init__(self,x,y):
        self.x=x
        self.y=y

        self.weights = np.zeros(x.shape[1])
        self.bias = 0

    def _sigmoid(self, x):
        return np.array([self._sigmoid_function(value) for value in x])

    def _sigmoid_function(self, x):
        if x >= 0:
            z = np.exp(-x)
            return 1 / (1 + z)
        else:
            z = np.exp(x)
            return z / (1 + z)

    def compute_loss(self, y_true, y_pred):
        # binary cross entropy
        y_zero_loss = y_true * np.log(y_pred + 1e-9)
        y_one_loss = (1-y_true) * np.log(1 - y_pred + 1e-9)
        return -np.mean(y_zero_loss + y_one_loss)

    def compute_gradients(self, x, y_true, y_pred):
        # derivative of binary cross entropy
        difference =  y_pred - y_true
        gradient_b = np.mean(difference)
        gradients_w = np.matmul(x.transpose(), difference)
        gradients_w = np.array([np.mean(grad) for grad in gradients_w])

        return gradients_w, gradient_b

    def update_model_parameters(self, error_w, error_b):
        self.weights = self.weights - 0.1 * error_w
        self.bias = self.bias - 0.1 * error_b

    def fit(self, x, y, epochs = 100):
        for i in range(epochs):
            x_dot_weights = np.matmul(self.weights, x.transpose()) + self.bias
            pred = self._sigmoid(x_dot_weights)
            loss = self.compute_loss(y, pred)
            error_w, error_b = self.compute_gradients(x, y, pred)
            self.update_model_parameters(error_w, error_b)

            pred_to_class = [1 if p > 0.5 else 0 for p in pred]
    
    def predict(self, x):
        x_dot_weights = np.matmul(x, self.weights.transpose()) + self.bias
        probabilities = self._sigmoid(x_dot_weights)
        return [1 if p > 0.5 else 0 for p in probabilities]


lr = LR(X_train,y_train)
lr.fit(X_train,y_train)
y_pred = lr.predict(X_test)

acc = compute_accuracy(y_pred,y_test)
print('accuracy = ', acc)