Breast Cancer prediction

__________________________

This project aims to predict breast cancer, using logistic regression machine learning algorithm.

__________________________

Run the code '21MI31010_A1.py' in any IDE with python 3.11 or newer

Change the location of the dataframe in code with its actual location.
_________________________


Required libraries:
	Numpy
	Pandas
	sklearn
	
_________________________

