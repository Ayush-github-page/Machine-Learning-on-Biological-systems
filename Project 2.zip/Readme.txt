•In any IDE, such as VS Code:

•Anaconda environment to be activated.

•Numpy: conda install -c anaconda numpy

•pandas: conda install pandas

•scikit-learn installation required : conda install scikit-learn

•Install Tensor flow, through the anaconda terminal:

	Create a conda environment:	conda create --name tf python=3.9 (replace number with your version)

	pip install tensorflow

	Verify the installation   python -c "import tensorflow as tf; print(tf.reduce_sum(tf.random.normal([1000, 1000])))"