Image classification using CNN
_____________________________

This code predicts malignant or benign cases through image classification using CNN

_____________________________

In order to run the code, the following libraries are required:

numpy: pip install numpy

tqdm : pip install tqdm

OpenCV : pip install opencv-python

tflearn : pip install tflearn

tensorflow : pip install tensorflow==1.12.0

pillow : pip install Pillow==9.5.0

________________________________

Run the 21MI31010_A2.py file

Change the path of the image files to the actual file location in the code.

The value of epochs, in line 104, can be changed in order to reduce the code execution time.
_________________________________

The Jupyter notebook has one run instance showing the predicted outputs.

__________________________________
