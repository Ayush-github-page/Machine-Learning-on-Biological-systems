												A back propagation neural network
												_________________________________
___________________________________________________________
How to run:

In any IDE:

Python environment,

Required numpy, pandas library.
____________________________________________________________

Code overview:

In cell 1: Change the path to locate to the dataset csv file

The operations performed are the following:

Cell 1: Data import

Cell 2: Processes the data

Cell 3: Builds the neural network. The Comment tags '#' can be removed  from certain code lines to see the the output printed

Cell 4: Can build neural network with user input of hidden layer size and learning rate.

Cell 5 and 6 : K fold cross validation.

Cell 7: Can be used to obtain error amount for any input of hidden layer size, learning rate and k value.

Cell 8: :Displays error amount for different cases
---------------------------------------------------------

Execute the code by running all the cells from top to bottom.