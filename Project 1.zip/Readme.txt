
---------------------------
Required libraries to be installed:

numpy: pip install numpy
panda:  pip install pandas

sklearn: pip install sklearn

graphviz: https://graphviz.org/download/

---------------------------------------------